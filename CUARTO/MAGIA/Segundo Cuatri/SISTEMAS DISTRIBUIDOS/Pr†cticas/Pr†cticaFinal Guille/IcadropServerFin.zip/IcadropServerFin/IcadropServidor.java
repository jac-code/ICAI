

import java.net.*;
import java.io.*;
import java.util.*;

public class IcadropServidor
{
	public static void main(String args[])
	{	
		
		String command ;
    	Process proc ;

		try
		{
			//Puesta en marcha de NFS en el caso de que no existiera todavia la carpeta del programa ICADROP
			command = "sudo mkdir /icadrop";

			proc = Runtime.getRuntime().exec(command);

	    	command = "sudo chown nobody:nogroup /icadrop";

			proc = Runtime.getRuntime().exec(command);

			command = "sudo chmod -R 777 /icadrop";

		
			proc = Runtime.getRuntime().exec(command);

			//cambio etc/exports SOBRA
			/*
			String filename= "/etc/exports";
	    	FileWriter fw = new FileWriter(filename,true); //the true will append the new data
	    	fw.write("\n/icadrop *(rw,sync,no_subtree_check)");//appends the string to the file
	    	fw.close();*/

			command = "sudo /etc/init.d/nfs-kernel-server restart";

			proc = Runtime.getRuntime().exec(command);

			//LOGIN
			/* Creamos un socket en el puerto de escucha */
			ServerSocket escuchandoSocket = new ServerSocket(5678);

			while(true)
			{
				/* Mediante el accept el servidor tiene acceso a los datos que envía el cliente */
				Socket socketCliente = escuchandoSocket.accept();

				//Creamos la conexión
				Conexion c = new Conexion(socketCliente);
			}
		}
		catch(IOException e)
		{
			System.out.println("Escuchando: " + e.getMessage());
		}
		catch (Exception e)
		{
			/* Lanzamos una excepción genérica en caso de error de ejecución */
			System.out.println("ERROR");
		}
	}
}
