
import java.net.*;
import java.io.*;
import java.util.*;

public class Conexion extends Thread
{
	DataInputStream dis;
	DataOutputStream dos;
	ObjectOutputStream oo;

	Socket socketCliente;
	String mensajeLogin;
	String operacion;
	String comando;
	String[] partesComando;
	int opcion;	

	Process proc;

	Usuario usuarioLoged;

	public Conexion(Socket unSocketCliente)
	{
		try
		{
			socketCliente = unSocketCliente;
			dis = new DataInputStream(socketCliente.getInputStream());
			dos = new DataOutputStream(socketCliente.getOutputStream());
			oo = new ObjectOutputStream(socketCliente.getOutputStream());
                

			/* Comenzamos el hilo */
			this.start();
		}
		catch(IOException e)
		{
			System.out.println("Conexion: " + e.getMessage());
		}
	}

	public void run()
	{
		try
		{
			/* Creamos un String para leer los datos */
			String mensajeRecibido;
			String[] mensajeDescompuesto; 
			String nombreIntroducido;
			String passwordIntroducido;
			Collection <Usuario> usuarios =  IOUsuario.leer(); 
			boolean existe = false;

			do
			{
				/* Leemos los datos del Stream */
				mensajeRecibido = dis.readUTF();
				mensajeDescompuesto = mensajeRecibido.split("-");
				nombreIntroducido = mensajeDescompuesto[0];
				passwordIntroducido = mensajeDescompuesto[1];

				/* Escribe la línea en el stream */
				System.out.println("\nMensaje: " + mensajeRecibido);
				
				for(Usuario i: usuarios){
					if(nombreIntroducido.equals(i.getNombre()) && passwordIntroducido.equals(i.getPassword())){
						existe=true;
						usuarioLoged=i;
					}
				}
				if(existe == true){
					mensajeLogin = "Usuario correcto";
					dos.writeUTF(mensajeLogin);
					oo.writeObject(usuarioLoged);
				}else{
					mensajeLogin = "Usuario incorrecto" ;
					dos.writeUTF(mensajeLogin);
				}
						
				
			}while(existe==false);

			System.out.println("\nConexion creada con "+usuarioLoged.getNombre());
			//Operaciones 
			do{

			operacion = dis.readUTF();

			System.out.println("\nOperacion "+operacion+" del user "+usuarioLoged.getNombre()+" recibida");
			opcion = Integer.parseInt(operacion.substring(0,1));

			switch(opcion){
					case 1:	

						partesComando = operacion.split("-");
						System.out.println("\nAñadiendo carpeta "+partesComando[1]+" a "+usuarioLoged.getNombre());

						comando = "sudo mkdir -p /icadrop/"+partesComando[1];

						proc = Runtime.getRuntime().exec(comando);
						
						for(Usuario i: usuarios){
							if(usuarioLoged.getNombre().equals(i.getNombre())){
								i.addCarpeta(partesComando[1]);								
							}
						}
						IOUsuario.escribir(usuarios);					
												
						break;
					case 2:
						
						partesComando = operacion.split("-");
						System.out.println("\nEliminando carpeta "+partesComando[1]+" de "+usuarioLoged.getNombre());

						
						
						for(Usuario i: usuarios){
							if(usuarioLoged.getNombre().equals(i.getNombre())){
								i.removeCarpeta(partesComando[1]);								
							}
						}
						IOUsuario.escribir(usuarios);

						break;
					
					case 4:
						partesComando = operacion.split("-");
						System.out.println("\nCompartiendo carpeta "+partesComando[1]+" de "+usuarioLoged.getNombre()+" a "+partesComando[2]);

						
						for(Usuario i: usuarios){
							if(partesComando[2].equals(i.getNombre())){
								i.addCarpeta(partesComando[1]);								
							}
						}
						IOUsuario.escribir(usuarios);
						break;
					
					case 0:
						System.out.println("\nCerrando conexion con "+usuarioLoged.getNombre());
						break;
					default:
						System.out.println("\nOPCION NO DISPONIBLE");
						break;

					}
			}while(opcion!=0);


		socketCliente.close();

		}
		catch(EOFException e)
		{
			System.out.println("EOF: " + e.getMessage());
		}
		catch(IOException e)
		{
			System.out.println("IO: " + e.getMessage());
		}			
	}	
}
