

import java.io.*;
import java.util.*;


public class IOUsuario
{
	public static Collection leer() 
	{
		Collection <Usuario> lista = new ArrayList<Usuario>();
		FileInputStream fis = null;
		ObjectInputStream ois = null;
		try
		{
			fis = new FileInputStream("usuarios.obj");
			ois = new ObjectInputStream (fis);
			while(true)
				lista.add((Usuario) ois.readObject());
		}
		catch(EOFException exception)
		{
			try
			{
				if(ois!=null)
					ois.close();				
				if(fis!=null)
					fis.close();
			}
			catch(IOException eio)
			{
				eio.printStackTrace();
			}
		}
		catch(FileNotFoundException exception)
		{
			exception.printStackTrace();
		}
		catch(ClassNotFoundException exception)
		{
			exception.printStackTrace();
		}		
		catch(IOException exception)
		{
			exception.printStackTrace();
		}
	
		return lista;
	}


	public static void escribir(Collection <Usuario> lista)
	{
		try
		{
			FileOutputStream fos = new FileOutputStream("usuarios.obj");
			ObjectOutputStream oos = new ObjectOutputStream (fos);

			
			for(Usuario i: lista)
				oos.writeObject(i);
			
			oos.close();
			fos.close();
		}
		catch(IOException exception)
		{
			exception.printStackTrace();
		}
	}
	
}