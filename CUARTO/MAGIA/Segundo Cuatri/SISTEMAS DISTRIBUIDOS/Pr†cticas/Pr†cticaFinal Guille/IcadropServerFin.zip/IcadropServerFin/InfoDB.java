import java.net.*;
import java.io.*;
import java.util.*;

public class InfoDB
{
	public static void main(String[] args)
	{
		
			System.out.println("\nBASE DE DATOS DE USUARIOS:");

			Collection <Usuario> usuarios =  IOUsuario.leer();
			for(Usuario i: usuarios){

			System.out.println(i.toString());
			}
	}	
		
}

