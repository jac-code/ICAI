#ifndef RETARDO_H
#define	RETARDO_H

#ifdef	__cplusplus
extern "C" {
#endif

    int Retardo(uint16_t retardo_ms);


#ifdef	__cplusplus
}
#endif

#endif	/* RETARDO_H */