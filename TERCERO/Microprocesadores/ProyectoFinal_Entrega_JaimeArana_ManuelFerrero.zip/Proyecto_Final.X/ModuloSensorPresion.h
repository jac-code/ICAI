#ifndef MODULOSENSORPRESION_H
#define	MODULOSENSORPRESION_H

#ifdef	__cplusplus
extern "C" {
#endif
    
    void InicializarSensorPresion();
    int getMedidaPresion();

#ifdef	__cplusplus
}
#endif

#endif	/* MODULOSENSORPRESION_H */

